/*
============================================================================
Name : 2.c
Author : Samarpita Bhaumik
Description :Write a simple program to execute in an infinite loop at the background. Go to /proc directory and
             identify all the process related information in the corresponding proc directory.
Date: 8th September, 2023.
============================================================================
*/
#include<unistd.h>
#include<stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
int main()
{
	while(1);
	return 0;
	
}
